﻿Font free for personal use only. 
If you want commercial use
you can purchase a license 
and full set of font at link below.
-------------------------------------------------
Purchase : https://www.jipatype.com/monkhang
My Store : https://www.jipatype.com/
-------------------------------------------------
Contact : anupapjaichumnan@gmail.com
Donate : https://www.paypal.me/akeanupap